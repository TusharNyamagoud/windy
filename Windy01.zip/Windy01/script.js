document.addEventListener("DOMContentLoaded", function() {
    const needle = document.getElementById("needle");
    const speedLabel = document.getElementById("speed-label");
    const powerValue = document.getElementById("power-value");
    const collectedValue = document.getElementById("collected-value");
    const consumptionValue = document.getElementById("consumption-value");
    const gauge = document.getElementById("gauge");
    const serviceLabel = document.getElementById("service-label");

    // Function to update the speedometer
    function updateSpeedometer(speed) {
        const maxSpeed = 100; // Max speed for the speedometer
        const rotation = (speed / maxSpeed) * 180; // Calculate rotation
        needle.style.transform = rotate(${rotation}deg);
        speedLabel.textContent = ${speed} km/h;
    }

    // Function to update power generation
    function updatePowerGeneration(power) {
        powerValue.textContent = ${power} MW;
    }

    // Function to update total energy collected
    function updateTotalEnergyCollected(energy) {
        collectedValue.textContent = ${energy} kWh;
    }

    // Function to update total energy consumption
    function updateTotalEnergyConsumption(energy) {
        consumptionValue.textContent = ${energy} kWh;
    }

    // Function to update service due gauge
    function updateServiceDue(serviceLevel) {
        gauge.style.width = ${serviceLevel}%;
        serviceLabel.textContent = Service Due: ${serviceLevel}%;
        gauge.style.backgroundColor = serviceLevel < 40 ? 'red' : 'green';
    }

    // Fetch and update all data
    async function fetchData() {
        try {
            const response = await fetch('https://api.example.com/dashboard-data'); // Replace with a real API endpoint
            const data = await response.json();

            // Update each metric with fetched data
            updateSpeedometer(data.windSpeed);
            updatePowerGeneration(data.powerGeneration);
            updateTotalEnergyCollected(data.totalEnergyCollected);
            updateTotalEnergyConsumption(data.totalEnergyConsumption);
            updateServiceDue(data.serviceDue);

        } catch (error) {
            console.error('Error fetching dashboard data:', error);
        }
    }

    // Update the dashboard every 5 seconds
    setInterval(fetchData, 5000);
});